<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbproject";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center"> Drug Record Print </h1>

<table border="4" align="center" style="line-height:25px;">
<tr>
<th>DrugID</th>
<th>Price</th>
<th>Quantity</th>
<th>Exp_Date</th>


</tr>
<?php
$sql = "SELECT * FROM drug";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['DrugID'];?></td>
<td> <?php  echo $row['Price'];?></td>
<td> <?php  echo $row['Quantity'];?></td>
<td> <?php  echo $row['Exp_Date'];?></td>


 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>