<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Clinix(The Medicine Superstore)";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center"> Bill Update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th> b_id</th>
<th>p_id</th>
<th>Doc_id</th>
<th>Drug_id</th>
<th>quatity</th>
<th>Discount</th>
<th>Total bill</th>

</tr>
<?php
$sql = "SELECT * FROM Bill";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['b_id'];?></td>
<td> <?php  echo $row['p_id'];?></td>
<td> <?php  echo $row['Doc_id'];?></td>
<td> <?php  echo $row['Drug_id'];?></td>
<td> <?php  echo $row['quantity'];?></td>
<td> <?php  echo $row['Discount'];?></td>
<td> <?php  echo $row['Total bill'];?></td>

 <td><a href="edit.php?edit_id=<?php echo $row['p_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>